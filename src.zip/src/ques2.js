import React from "react";

function Que1({name})
{
    return(
        <>
          <h1>Hello {name}</h1>
        </>
    )
}

export default class Que extends React.Component
{
  render()
  {
    return(
        <>
        <h1>Welcome to React!</h1>
         <Que1 name={"Mohit"}></Que1>
        </>
    )
  }  
}