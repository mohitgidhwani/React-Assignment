import logo from './logo.svg';
import './App.css';
import Que1 from './ques2';
import Que3 from './que3';
import Button from './que4';
import Input from './que4';
import Login from './que5';
import List from './que6';
import Info from './que7';

function App() {
  return (
    <div className="App">
       <h1>Hello,React!</h1>
       <Que1></Que1>
       <Que3></Que3>
       {/* <Button></Button> */}
       <Input></Input>
       <Login></Login>
       <List></List>
       <Info></Info>
    </div>
    
  );
}

export default App;
