import React from "react";

export default class List extends React.Component
{
    arr = [{fruit:"Orange"},
        {fruit:"Mango"},
        {fruit:"Banana"},
        {fruit:"Kivi"}
    ]
  render()
  {
    return(
        <>
          {this.arr.map((v)=>(
           <li>{v.fruit}</li>
          )
        
          )}
        </>
    )
  }
}