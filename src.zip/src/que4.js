function Button()
{

    function btn()
    {
       const btn_tag = document.getElementById('btnclick');

        btn_tag.innerHTML = "Clicked"
    }
    return(
        <>
      <button id="btnclick" onClick={btn} style={{margin:"50px 0"}}>Not Clicked</button>
        </>
    )
}


export default function Input()
{
    function text()
    {
      const input_tag = document.getElementById('input');
      const result = document.getElementById('result');

      result.innerHTML = input_tag.value


    }

    


    return(
        <>
        <Button></Button>
        <br></br>

        <input type="text" id="input" onKeyDown={text}></input>
        <h3 id="result"></h3>
        </>
    )
}
