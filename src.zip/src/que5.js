function Vote()
{

    function number()
    {
        const age_tag = document.getElementById('age');
        const age = document.getElementById('ageres');

        if(age_tag.value >= 18)
        {
          age.innerHTML= ("Vote Confirmed")
        }
        else
        {
            age.innerHTML= ("Under Age") 
        }
    }
  return(
    <>
      <input id="age" type="number"></input>
      <button id="submit" onClick={number}>Vote</button>
      <h4 id="ageres"></h4>
    </>
  )
}


export default function Login()
{
    return(
        <>
        <Vote></Vote>

        
        </>
    )
}


