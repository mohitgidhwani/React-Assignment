import React from 'react'
import './App.css'
const arr = [
    {name:"Mohit",age:22,location:"India"}
]

  class Que extends React.Component
  {

    state = {x:0}

     plus = ()=>
    {
       this.setState(()=>{
          return {x:this.state.x +1}
       })
    }
  render()
  {
    return(
        <>
        <h1>{this.state.x}</h1>
        <button onClick={this.plus}>+</button>
        </>
    )
  }
  }


export default function Que3()
{
  return(
    <>
    <div className="Container">
        <div className="row">
            {arr.map((v)=>{
                return(
                   <div key={v.id} className="card">
                     <h4>{v.name}</h4>
                     <h4>{v.age}</h4>
                     <h4>{v.location}</h4>
                   </div>
                )
            })}
        </div>
        <Que></Que>
    </div>
    </>
  )
}