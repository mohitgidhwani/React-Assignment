import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Link, Route, Router, Routes } from 'react-router-dom';
import Home from './Home';
import   "../node_modules/bootstrap/dist/css/bootstrap.css"
import Contact from './Contact';
import About from './About';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Link to={'/home'} className='btn btn-success mt-5 mx-5'>Home</Link>
      <Link to={'/contact'} className='btn btn-success mt-5 mx-5'>Contact</Link>
      <Link to={'/about'} className='btn btn-success mt-5 mx-5'>Contact</Link>
        <Routes>
          <Route path='/home' element={<Home></Home>}></Route>
          <Route path='/contact' element={<Contact></Contact>}></Route>
          <Route path='/about' element={<About></About>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
