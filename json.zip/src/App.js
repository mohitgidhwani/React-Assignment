
import './App.css';

// import Change from './stateoprations';

import { Suspense, useState } from 'react';


import { BrowserRouter, Link, NavLink, Route, Routes } from 'react-router-dom';


import About from './About';


import Adddata from './Adddata';
import Edit from './Edit';




const frinds = [
  { id: 1, name: "Mohit", location: "India" },
  { id: 2, name: "Yuvraj", location: "UK" },
  { id: 3, name: "Samay", location: "Singapore" },
  { id: 4, name: "Raju", location: "USA" },
  { id: 5, name: "Birju", location: "Canada" }
]
let index = 6;


export default function Test() {

  const [todos, setTodos] = useState(frinds)

  const handleAdd = (frinds) => {



    setTodos(
      [
        ...todos,
        { id: index++, name: frinds }
      ]
    )
  }

  const handleEdit = (nextObj) => {
    // console.log(nextObj)

    setTodos(todos.map((v) => {
      if (v.id == nextObj.id) {
        return nextObj;
      }
      else {
        return v
      }
    }))
  }

  const handleDelete = (objId) => {
    console.log(objId);

    setTodos(todos.filter((v) => {
      return v.id !== objId
    }))
  }



  return (
    <>
      <h1>hello</h1>
      <div className='App'>

      
        <Animation></Animation>

        <BrowserRouter>
          <Routes>
            <Route path='/' element={<About></About>}></Route>
            <Suspense fallback={<Animation></Animation>}>
              <Route path='/add' element={<Adddata></Adddata>}></Route>
            </Suspense>
            <Route path='/edit/:id' element={<Edit></Edit>}></Route>
          </Routes>
        </BrowserRouter>
      </div>



    </>
  )
}





















