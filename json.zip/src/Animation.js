import React from 'react'

function Animation() {
  return (
    <>
    <div className='loading'></div>
    </>
  )
}

export default Animation